Neben der aktuellen Version der CardService.wsdl und CardService.xsd MUSS der Konnektor gemäß TIP1-A_4586
auch ältere Versionen unterstützen. 
Zur Vollständigkeit sind diese älteren zu unterstützenden Versionen in diesem Schemapaket unter dem Namen
  CardService_v<version>.wsdl
  CardService_v<version>.xsd
enthalten.
